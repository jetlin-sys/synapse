# iwhalecloud.foundation.py
"""
Helper Package
辅助工具包
"""

__version__ = '1.0.0'
