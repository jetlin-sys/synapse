# 读取配置表数据
from foundation.helper.Error import *
import json
from typing import Dict, Any, Tuple, Optional
import os
from threading import Lock
from foundation.helper.LogHelper import logger

# 全局配置实例缓存和锁
_global_cfg_instance = None
_global_cfg_lock = Lock()

# 加载配置表的类
class cfgHelper():
    def __init__(self, cfg_file: str = 'config/BSS_REINFORCE.json'):
        self.cfg_file: str = cfg_file
        self.sysCfg: Optional[Dict[str, Any]] = None

    # 加载BSS_REINFORCE.json数据
    def loadSysCfg(self) -> Tuple[int, str]:
        """
        加载系统配置文件
        
        Returns:
            Tuple[int, str]: 返回状态码和消息
        """
        try:
            # 如果是相对路径，则基于项目根目录构建绝对路径
            fileName = self.cfg_file
            if not os.path.isabs(fileName):
                cwd_path = os.path.join(os.getcwd(), fileName)
                if os.path.exists(cwd_path):
                    fileName = cwd_path

            # 检查文件是否存在
            if not os.path.exists(fileName):
                return ERROR_DB_CONFIG_MISSING, f"配置文件不存在: {fileName}"
            
            # 读取并解析配置文件
            with open(fileName, 'r', encoding='utf-8') as f:
                self.sysCfg = json.load(f)
                
            # 验证配置数据
            if self.sysCfg is None:
                return ERROR_DB_CONFIG_MISSING, f"配置文件内容为空: {fileName}"
                
            if not isinstance(self.sysCfg, dict):
                return ERROR_DB_CONFIG_FORMAT_ERROR, f"配置文件格式错误，应为JSON对象: {fileName}"

            # 解密数据库密码（支持多个数据源）
            data_source_root = self.sysCfg.get("data_source", None)
            if data_source_root is None or not isinstance(data_source_root, dict):
                return ERROR_DB_CONFIG_MISSING, f"配置文件中未找到data_source"
            
            from foundation.helper.CryptHelper import CryptHelper
            crypt = CryptHelper()
            processed_any = False

            # 处理其它数据源，如 cust，以及未来新增的数据源
            for name, ds in data_source_root.items():
                if isinstance(ds, dict):
                    pwd = ds.get("password", None)
                    if pwd is None:
                        logger.warning(f"数据源[{name}]未配置password，跳过解密")
                        continue
                    dec = crypt.decrypt(pwd)
                    if dec is None:
                        return ERROR_DB_CONFIG_FORMAT_ERROR, f"数据源[{name}]密码解密失败"
                    ds["password"] = dec
                    processed_any = True

            if not processed_any:
                return ERROR_DB_CONFIG_MISSING, f"配置文件中未找到任何需要解密的数据库密码"

            return SUCCESS, SUCCESS_MSG
            
        except FileNotFoundError:
            return ERROR_CONFIG_FILE_NOT_FOUND, f"配置文件不存在: {fileName}"
        except json.JSONDecodeError as e:
            return ERROR_CONFIG_FILE_FORMAT_ERROR, f"配置文件JSON格式错误: {str(e)}"
        except UnicodeDecodeError as e:
            return ERROR_CONFIG_FILE_ENCODING_ERROR, f"配置文件编码错误: {str(e)}"
        except IOError as e:
            return ERROR_CONFIG_FILE_LOAD_FAILED, f"配置文件读取失败: {str(e)}"
        except Exception as e:
            return ERROR_CONFIG_FILE_UNKNOWN_ERROR, f"加载配置文件时发生未知错误: {str(e)}"

    # 获取系统配置
    def getCfgValue(self, item: str, value: str, default: Optional[Any] = None) -> Optional[Any]:
        """
        获取配置项的值
        
        Args:
            item: 配置项名称
            value: 配置值名称
            
        Returns:
            Optional[Any]: 配置值，如果不存在则返回None
        """
        # 检查系统配置是否已加载
        if self.sysCfg is None:
            return None
            
        # 获取配置项
        itemValue = self.sysCfg.get(item, None)
        if itemValue is None:
            return None
            
        # 如果配置项不是字典类型，直接返回None
        if not isinstance(itemValue, dict):
            return None
            
        return itemValue.get(value, default)


def getGlobalConfig(cfg_file: Optional[str] = None) -> Tuple[int, Optional['cfgHelper']]:
    
    """
    获取全局配置实例 - 单例模式，确保只加载一次，线程安全
    
    Args:
        cfg_file: 配置文件路径（可选）
                 - 如果提供绝对路径，直接使用
                 - 如果提供相对路径，会基于调用方的工作目录根目录查找
                 - 如果不提供，默认使用 'config/BSS_REINFORCE.json'
    
    Returns:
        Tuple[int, Optional[cfgHelper]]: 返回状态码和配置实例
    """
    global _global_cfg_instance
    if _global_cfg_instance is None:
        with _global_cfg_lock:
            if _global_cfg_instance is None:
                # 如果指定了配置文件路径，使用指定的路径
                if cfg_file is not None:
                    cfg = cfgHelper(cfg_file)
                else:
                    cfg = cfgHelper()
                code, msg = cfg.loadSysCfg()
                if code != SUCCESS:
                    logger.error(f"加载系统配置失败：{msg}")
                    return code, None
                _global_cfg_instance = cfg
                logger.info("系统配置加载成功")
    
    return SUCCESS, _global_cfg_instance


def resetGlobalConfig():
    """
    重置全局配置实例（主要用于测试或重新加载配置）
    """
    global _global_cfg_instance
    with _global_cfg_lock:
        _global_cfg_instance = None

