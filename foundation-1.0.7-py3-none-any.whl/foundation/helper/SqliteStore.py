# -*- coding: utf-8 -*-
"""通用 SQLite 连接封装（DEFERRED 事务，execute/query 内 commit/rollback）。"""

from __future__ import annotations

import sqlite3
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from foundation.helper.Error import SUCCESS, SUCCESS_MSG

# ---------- 配置 / PRAGMA ----------
PRAGMA_JOURNAL_WAL = "PRAGMA journal_mode = WAL"
PRAGMA_SYNCHRONOUS_NORMAL = "PRAGMA synchronous = NORMAL"
PRAGMA_BUSY_TIMEOUT = "PRAGMA busy_timeout = 5000"


# sqllite操作类
class SqliteStore:
    def __init__(
        self,
        dbdir: str | Path,
        dbfile: str,
        create: bool = False,
        ddl_list: Optional[List[str]] = None,
    ) -> None:
        self.dbfile = dbfile
        self._data_db_dir = Path(dbdir).expanduser()
        self.db_path = self._data_db_dir / self.dbfile

        if not self.db_path.is_file():
            if not create:
                raise ValueError("数据库文件不存在，请先创建")
            self._data_db_dir.mkdir(parents=True, exist_ok=True)
        self.conn = self.connect()

        if ddl_list is not None:
            for stmt in ddl_list:
                self.conn.execute(stmt.strip())

    def connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(
            str(self.db_path),
            timeout=5,
            check_same_thread=False,
            isolation_level="DEFERRED",
        )
        conn.row_factory = sqlite3.Row
        conn.execute(PRAGMA_BUSY_TIMEOUT)
        conn.execute(PRAGMA_JOURNAL_WAL)
        conn.execute(PRAGMA_SYNCHRONOUS_NORMAL)
        conn.commit()

        return conn

    def _row_to_dict(self, row: Optional[sqlite3.Row]) -> Optional[Dict[str, Any]]:
        if row is None:
            return None
        return dict(row)

    def query(self, sql, args: Optional[tuple] = None) -> Tuple[int, str, Any]:
        try:
            if args is None:
                cur = self.conn.execute(sql)
            else:
                cur = self.conn.execute(sql, args)

            rows = cur.fetchall() or []
            data: List[Any] = []
            for r in rows:
                if isinstance(r, dict):
                    data.append(r)
                    continue
                try:
                    data.append(dict(r))
                except Exception:
                    data.append(r)
            return SUCCESS, SUCCESS_MSG, data
        except Exception as e:
            self.conn.rollback()
            return -1, str(e), []

    def execute(self, sql, args: Optional[tuple] = None) -> Tuple[int, str]:
        try:
            if args is None:
                self.conn.execute(sql)
            else:
                self.conn.execute(sql, args)
            return SUCCESS, SUCCESS_MSG
        except Exception as e:
            return -1, str(e)

    def commit(self) -> None:
        self.conn.commit()

    def rollback(self) -> None:
        self.conn.rollback()
