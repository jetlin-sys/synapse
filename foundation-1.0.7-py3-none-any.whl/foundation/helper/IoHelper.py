from flask import jsonify
from typing import Dict, Any

def validateRequiredFields(data: Dict[str, Any], required_fields: list) -> tuple:
    """
    验证必填字段
    
    Args:
        data: 待验证的数据
        required_fields: 必填字段列表
        
    Returns:
        tuple: (是否有效, 错误消息)
    """
    if not data:
        return False, "数据不能为空"
    
    missing_fields = []
    for field in required_fields:
        if field not in data or data[field] is None or data[field] == "":
            missing_fields.append(field)
    
    if missing_fields:
        return False, f"缺少必填字段: {', '.join(missing_fields)}"
    
    return True, ""

def createRsp(code, msg, data="", total=0):
    return jsonify({"code": code, "message": f"{msg}", "data": data, "total": total})

def createRspFail(msg):
    return jsonify({"code": -1, "message": f"{msg}", "data": None})

def isSubset(subset, superset):
    if len(superset) == 0:
        return False
    if len(subset) == 0:
        return True

    if isinstance(subset,dict):
        subsetNew = subset.copy()
        subsetNew.pop("reason", None)
        keys = subsetNew.keys()
        target_keys = {k: subsetNew[k] for k in keys if k in subsetNew}
        for item in superset:
            if all(key in item for key in keys):
                # 动态比较所有指定字段的值
                if all(item[key] == target_keys[key] for key in keys):
                    return True
        return False
    elif isinstance(subset,list):
        for item in subset:
            if item not in superset:
                return False
        return True
    elif isinstance(subset,str):
        return subset in superset
    else:
        return False
