"""
跨进程文件锁：Windows 使用 msvcrt.locking，Unix 使用 flock，阻塞等待。
用于保护基于文件的读写（如 JSON 配置）避免并发损坏。
"""
import os
import sys


class GlobalFileLock:
    """
    基于独立锁文件的互斥锁，可与被保护资源同目录或任意路径。
    Windows 下空文件需至少 1 字节才能对区间加锁，故首次创建时写入 \\0。
    """

    def __init__(self, lock_path: str):
        self.lock_path = lock_path
        self._fh = None

    def __enter__(self):
        lock_dir = os.path.dirname(self.lock_path)
        if lock_dir:
            os.makedirs(lock_dir, exist_ok=True)
        self._fh = open(self.lock_path, 'a+b')
        if os.path.getsize(self.lock_path) == 0:
            self._fh.write(b'\0')
            self._fh.flush()
        self._fh.seek(0)
        if sys.platform == 'win32':
            import msvcrt
            msvcrt.locking(self._fh.fileno(), msvcrt.LK_LOCK, 1)
        else:
            import fcntl
            fcntl.flock(self._fh.fileno(), fcntl.LOCK_EX)
        return self

    def __exit__(self, exc_type, exc, tb):
        if self._fh:
            try:
                if sys.platform == 'win32':
                    import msvcrt
                    self._fh.seek(0)
                    msvcrt.locking(self._fh.fileno(), msvcrt.LK_UNLCK, 1)
                else:
                    import fcntl
                    fcntl.flock(self._fh.fileno(), fcntl.LOCK_UN)
            except OSError:
                pass
            self._fh.close()
            self._fh = None
        return False
