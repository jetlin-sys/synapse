import os
import sys
import logging
import threading
from logging.handlers import TimedRotatingFileHandler
import datetime
import atexit
import signal
from typing import Optional


class DailyRotatingLogger(logging.Logger):
    """
    支持跨天自动切换的自定义Logger类
    """
    def __init__(self, name, log_helper_instance):
        super().__init__(name)
        self.log_helper = log_helper_instance
    
    def _log(self, level, msg, args, exc_info=None, extra=None, stack_info=False, stacklevel=1):
        """重写_log方法，在每次记录日志前检查日期"""
        # 检查是否需要切换日志目录
        self.log_helper._check_and_rotate_daily()
        # 调用父类的_log方法，增加stacklevel以正确显示调用位置
        super()._log(level, msg, args, exc_info, extra, stack_info, stacklevel + 1)


class LogHelper:
    """
    优化的日志助手类
    - 支持单例模式，避免重复初始化
    - 按日期目录区分日志文件
    - 统一日志目录结构，避免多线程文件分散
    - 增加异常处理和配置验证
    - 支持跨天自动切换日志目录
    """
    _instance = None
    _lock = threading.Lock()
    
    def __new__(cls, *args, **kwargs):
        """单例模式，确保只有一个LogHelper实例"""
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super(LogHelper, cls).__new__(cls)
        return cls._instance

    def __init__(self, log_level: int = logging.INFO, log_dir: str = "log",
                 max_backup_days: int = 7, console_output: bool = True):
        """
        初始化日志助手

        Args:
            log_level: 日志级别，默认INFO
            log_dir: 日志根目录，默认"log"，会与 HOME 环境变量拼接为绝对路径
            max_backup_days: 最大备份天数，默认7天
            console_output: 是否输出到控制台，默认True
        """
        # 初始化属性，避免后续访问前未定义错误
        self._initialized = False
        self._rotating = False

        # 避免重复初始化
        if self._initialized:
            return
            
        self.log_level = log_level
        # 使用 HOME 环境变量将日志路径解析为绝对路径（Windows 下 HOME 未设置时使用 USERPROFILE）
        home = os.environ.get('HOME') or os.path.expanduser('~')
        self.log_dir = os.path.join(home, log_dir) if not os.path.isabs(log_dir) else log_dir
        self.max_backup_days = max_backup_days
        self.console_output = console_output
        
        # 记录当前日期，用于跨天检查
        self.current_date = datetime.datetime.now().strftime('%Y%m%d')
        
        # 直接创建自定义Logger实例
        self.logger = DailyRotatingLogger('threshold_system', self)
        self.logger.setLevel(log_level)
        
        # 将logger注册到logging系统中
        logging.Logger.manager.loggerDict['threshold_system'] = self.logger
        
        # 清除可能存在的旧处理器，确保关闭文件句柄
        self._close_all_handlers()
        
        try:
            self._setup_handlers()
            self._cleanup_old_logs()  # 清理旧日志
            self._setup_exit_handlers()  # 设置退出处理器
            self._initialized = True
            self.logger.info("LogHelper初始化完成")
        except Exception as e:
            print(f"LogHelper初始化失败: {e}")
            # 降级到基本控制台日志
            self._setup_fallback_logger()
            self._initialized = True

    def _get_today_log_dir(self) -> str:
        """
        获取今天的日志目录路径
        
        Returns:
            str: 今天的日志目录路径
        """
        today = datetime.datetime.now().strftime('%Y%m%d')
        return os.path.join(self.log_dir, today)

    def _ensure_log_directory(self) -> str:
        """
        确保今天的日志目录存在
        
        Returns:
            str: 今天的日志目录路径
        """
        try:
            today_log_dir = self._get_today_log_dir()
            os.makedirs(today_log_dir, exist_ok=True)
            return today_log_dir
        except Exception as e:
            print(f"创建日志目录失败: {e}")
            # 降级到 HOME 下的备用目录
            home = os.environ.get('HOME') or os.path.expanduser('~')
            fallback_dir = os.path.join(home, 'logs_fallback')
            os.makedirs(fallback_dir, exist_ok=True)
            return fallback_dir

    def _close_all_handlers(self):
        """
        关闭所有文件处理器，防止句柄泄漏
        """
        try:
            handlers_to_close = []
            for handler in self.logger.handlers:
                if isinstance(handler, logging.FileHandler):
                    handlers_to_close.append(handler)
            
            for handler in handlers_to_close:
                try:
                    handler.close()
                except Exception as e:
                    print(f"关闭处理器时发生错误: {e}")
                finally:
                    self.logger.removeHandler(handler)
                    
        except Exception as e:
            print(f"清理处理器时发生错误: {e}")

    def _setup_exit_handlers(self):
        """
        设置进程退出时的清理处理器
        """
        try:
            # 注册atexit清理函数
            atexit.register(self._cleanup_on_exit)
            
            # 注册信号处理器
            if hasattr(signal, 'SIGTERM'):
                signal.signal(signal.SIGTERM, self._signal_handler)
            if hasattr(signal, 'SIGINT'):
                signal.signal(signal.SIGINT, self._signal_handler)
                
        except Exception as e:
            print(f"设置退出处理器失败: {e}")

    def _signal_handler(self, signum, frame):
        """
        信号处理器，确保在进程被终止时清理资源
        """
        try:
            print(f"接收到信号 {signum}，开始清理日志资源...")
            self._cleanup_on_exit()
        except Exception as e:
            print(f"信号处理器清理失败: {e}")
        finally:
            # 恢复默认信号处理并重新发送信号
            signal.signal(signum, signal.SIG_DFL)
            os.kill(os.getpid(), signum)

    def _cleanup_on_exit(self):
        """
        进程退出时的清理方法
        """
        try:
            if hasattr(self, 'logger') and self.logger:
                self.logger.info("LogHelper正在清理资源...")
                self._close_all_handlers()
                print("LogHelper资源清理完成")
        except Exception as e:
            print(f"退出清理失败: {e}")

    def __del__(self):
        """
        析构方法，确保对象销毁时关闭文件句柄
        """
        try:
            self._cleanup_on_exit()
        except:
            pass

    def __enter__(self):
        """
        上下文管理器入口
        """
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """
        上下文管理器出口，确保资源清理
        """
        try:
            self._cleanup_on_exit()
        except Exception as e:
            print(f"上下文管理器清理失败: {e}")
        return False  # 不抑制异常

    def _check_and_rotate_daily(self):
        """
        检查是否跨天，如果跨天则更新日志目录和文件处理器
        """
        try:
            # 检查 Python 是否正在关闭，如果是则直接返回
            import sys
            if sys.meta_path is None:
                return
            
            current_date = datetime.datetime.now().strftime('%Y%m%d')

            # 如果日期没有变化，直接返回
            if current_date == getattr(self, 'current_date', current_date):
                return
            
            # 防止递归调用：设置标志位
            if getattr(self, '_rotating', False):
                return
                
            self._rotating = True
            
            try:
                # 日期发生变化，需要切换日志目录
                print(f"检测到日期变化: {self.current_date} -> {current_date}, 开始切换日志目录")
                
                # 更新当前日期
                old_date = self.current_date
                self.current_date = current_date
                
                # 重新设置处理器
                self._rotate_handlers()
                
                print(f"日志目录切换完成: {old_date} -> {current_date}")
                
                # 切换完成后记录一条日志
                self.logger.info(f"日志目录已切换: {old_date} -> {current_date}")
                
            finally:
                self._rotating = False
            
        except Exception as e:
            # 避免在日志系统内部出错影响主程序
            print(f"跨天切换日志目录时发生错误: {e}")
            if hasattr(self, '_rotating'):
                self._rotating = False

    def _rotate_handlers(self):
        """
        轮换文件处理器，切换到新的日志目录
        """
        try:
            # 保存控制台处理器
            console_handlers = []
            for handler in self.logger.handlers:
                if isinstance(handler, logging.StreamHandler) and not isinstance(handler, logging.FileHandler):
                    console_handlers.append(handler)
            
            # 关闭所有文件处理器
            self._close_all_handlers()
            
            # 重新添加控制台处理器
            for handler in console_handlers:
                if handler not in self.logger.handlers:
                    self.logger.addHandler(handler)
            
            # 创建新的文件处理器
            self._setup_file_handlers()
            
        except Exception as e:
            print(f"轮换处理器时发生错误: {e}")

    def _setup_file_handlers(self):
        """
        设置文件处理器
        """
        try:
            # 确保新日期的日志目录存在
            log_dir = self._ensure_log_directory()
            filename = self._generate_log_filename()
            log_path = os.path.join(log_dir, filename)

            # 创建主文件处理器
            file_handler = logging.FileHandler(
                log_path,
                encoding='utf-8',
                mode='a'  # 追加模式
            )
            file_handler.setLevel(self.log_level)

            # 设置统一日志格式
            formatter = logging.Formatter(
                '%(asctime)s|%(levelname)s|%(name)s|%(process)d|%(thread)d|%(funcName)s|%(filename)s:%(lineno)d|%(message)s'
            )
            file_handler.setFormatter(formatter)
            self.logger.addHandler(file_handler)
            
            # 重新创建额外的文件处理器
            self._recreate_extra_handlers(log_dir, formatter)
            
        except Exception as e:
            print(f"设置文件处理器时发生错误: {e}")

    def _recreate_extra_handlers(self, log_dir: str, formatter):
        """
        重新创建额外的文件处理器
        
        Args:
            log_dir: 日志目录
            formatter: 日志格式器
        """
        if not (hasattr(self, '_extra_handlers') and self._extra_handlers):
            return
            
        for handler_info in self._extra_handlers:
            try:
                extra_log_path = os.path.join(log_dir, handler_info['filename'])
                
                extra_handler = logging.FileHandler(extra_log_path, encoding='utf-8', mode='a')
                extra_handler.setLevel(handler_info['level'])
                extra_handler.setFormatter(formatter)
                extra_handler._is_extra_handler = True
                extra_handler._extra_filename = handler_info['filename']
                self.logger.addHandler(extra_handler)
                
            except Exception as e:
                print(f"重建额外处理器 {handler_info['filename']} 失败: {e}")

    def _generate_log_filename(self) -> str:
        """
        生成日志文件名（不包含日期，因为已经按目录区分）
        
        Returns:
            str: 日志文件名
        """
        process_name = os.path.basename(sys.argv[0]).replace('.py', '')
        pid = os.getpid()
        # 移除线程ID，避免多线程文件分散
        return f"{process_name}_{pid}.log"

    def _setup_handlers(self):
        """配置日志处理器（文件和控制台）"""
        # 设置文件处理器
        self._setup_file_handlers()
        
        # 创建控制台日志处理器（可选）
        if self.console_output:
            console_handler = logging.StreamHandler()
            console_handler.setLevel(self.log_level)
            formatter = logging.Formatter(
                '%(asctime)s|%(levelname)s|%(name)s|%(process)d|%(thread)d|%(funcName)s|%(filename)s:%(lineno)d|%(message)s'
            )
            console_handler.setFormatter(formatter)
            self.logger.addHandler(console_handler)

    def _setup_fallback_logger(self):
        """设置降级的控制台日志"""
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.INFO)
        formatter = logging.Formatter(
            '%(asctime)s|%(levelname)s|%(process)d|%(thread)d|%(message)s'
        )
        console_handler.setFormatter(formatter)
        self.logger.addHandler(console_handler)

    def _cleanup_old_logs(self):
        """清理超过保留天数的旧日志目录"""
        try:
            if not os.path.exists(self.log_dir):
                return
                
            # 获取当前日期
            current_date = datetime.datetime.now()
            
            # 遍历日志根目录下的所有子目录
            for item in os.listdir(self.log_dir):
                item_path = os.path.join(self.log_dir, item)
                
                # 检查是否是目录且符合日期格式 YYYYMMDD
                if os.path.isdir(item_path) and len(item) == 8 and item.isdigit():
                    try:
                        # 解析目录名为日期
                        dir_date = datetime.datetime.strptime(item, '%Y%m%d')
                        
                        # 计算日期差
                        days_diff = (current_date - dir_date).days
                        
                        # 如果超过保留天数，删除整个目录
                        if days_diff > self.max_backup_days:
                            import shutil
                            shutil.rmtree(item_path)
                            print(f"已清理旧日志目录: {item_path}")
                            
                    except ValueError:
                        # 忽略不符合日期格式的目录
                        continue
                        
        except Exception as e:
            print(f"清理旧日志时发生错误: {e}")

    def set_level(self, level: int):
        """
        动态设置日志级别
        
        Args:
            level: 新的日志级别
        """
        self.log_level = level
        self.logger.setLevel(level)
        for handler in self.logger.handlers:
            handler.setLevel(level)
        self.logger.info(f"日志级别已调整为: {logging.getLevelName(level)}")

    def setInfoLevel(self):
        """设置为INFO级别"""
        self.set_level(logging.INFO)

    def setWarnLevel(self):
        """设置为WARNING级别"""
        self.set_level(logging.WARNING)

    def setDebugLevel(self):
        """设置为DEBUG级别"""
        self.set_level(logging.DEBUG)

    def setErrorLevel(self):
        """设置为ERROR级别"""
        self.set_level(logging.ERROR)

    def setCriticalLevel(self):
        """设置为CRITICAL级别"""
        self.set_level(logging.CRITICAL)

    def get_logger(self) -> logging.Logger:
        """
        获取logger实例
        
        Returns:
            logging.Logger: 配置好的logger实例
        """
        return self.logger

    def add_file_handler(self, filename: str, level: Optional[int] = None):
        """
        添加额外的文件处理器（保存到今天的日志目录）
        注意：额外的文件处理器也会在跨天时自动切换目录
        
        Args:
            filename: 文件名
            level: 日志级别，默认使用当前级别
        """
        file_handler = None
        try:
            # 存储额外处理器信息，用于跨天重建
            if not hasattr(self, '_extra_handlers'):
                self._extra_handlers = []
            
            handler_info = {
                'filename': filename,
                'level': level or self.log_level
            }
            self._extra_handlers.append(handler_info)
            
            # 创建处理器
            log_dir = self._ensure_log_directory()
            log_path = os.path.join(log_dir, filename)
            
            file_handler = logging.FileHandler(log_path, encoding='utf-8')
            file_handler.setLevel(level or self.log_level)
            
            formatter = logging.Formatter(
                '%(asctime)s|%(levelname)s|%(name)s|%(process)d|%(thread)d|%(funcName)s|%(filename)s:%(lineno)d|%(message)s'
            )
            file_handler.setFormatter(formatter)
            # 标记这是额外处理器，方便识别
            file_handler._is_extra_handler = True
            file_handler._extra_filename = filename
            self.logger.addHandler(file_handler)
            
            self.logger.info(f"已添加文件处理器: {filename}")
        except Exception as e:
            # 如果创建失败，确保关闭已创建的文件句柄
            if file_handler:
                try:
                    file_handler.close()
                except:
                    pass
            # 从额外处理器列表中移除失败的项
            if hasattr(self, '_extra_handlers') and handler_info in self._extra_handlers:
                self._extra_handlers.remove(handler_info)
            self.logger.error(f"添加文件处理器失败: {e}")

    def get_log_stats(self) -> dict:
        """
        获取日志统计信息
        
        Returns:
            dict: 日志统计信息
        """
        stats = {
            'logger_name': self.logger.name,
            'current_level': logging.getLevelName(self.logger.level),
            'handlers_count': len(self.logger.handlers),
            'log_root_directory': self.log_dir,
            'today_log_directory': self._get_today_log_dir(),
            'current_tracked_date': self.current_date,
            'max_backup_days': self.max_backup_days,
            'daily_rotation_enabled': True,
            'extra_handlers_count': len(getattr(self, '_extra_handlers', []))
        }
        
        # 统计各类型处理器
        handler_types = {}
        for handler in self.logger.handlers:
            handler_type = type(handler).__name__
            handler_types[handler_type] = handler_types.get(handler_type, 0) + 1
        
        stats['handler_types'] = handler_types
        
        # 统计日志目录信息
        try:
            if os.path.exists(self.log_dir):
                log_dirs = []
                for item in os.listdir(self.log_dir):
                    item_path = os.path.join(self.log_dir, item)
                    if os.path.isdir(item_path) and len(item) == 8 and item.isdigit():
                        log_dirs.append(item)
                stats['existing_log_dates'] = sorted(log_dirs)
                stats['total_log_directories'] = len(log_dirs)
        except Exception as e:
            stats['directory_scan_error'] = str(e)
        
        return stats

    def force_cleanup_logs(self) -> dict:
        """
        强制清理旧日志并返回清理结果
        
        Returns:
            dict: 清理结果统计
        """
        cleanup_result = {
            'cleaned_directories': [],
            'errors': [],
            'total_cleaned': 0
        }
        
        try:
            if not os.path.exists(self.log_dir):
                return cleanup_result
                
            current_date = datetime.datetime.now()
            
            for item in os.listdir(self.log_dir):
                item_path = os.path.join(self.log_dir, item)
                
                if os.path.isdir(item_path) and len(item) == 8 and item.isdigit():
                    try:
                        dir_date = datetime.datetime.strptime(item, '%Y%m%d')
                        days_diff = (current_date - dir_date).days
                        
                        if days_diff > self.max_backup_days:
                            import shutil
                            shutil.rmtree(item_path)
                            cleanup_result['cleaned_directories'].append(item)
                            cleanup_result['total_cleaned'] += 1
                            
                    except Exception as e:
                        cleanup_result['errors'].append(f"清理 {item} 时出错: {str(e)}")
                        
        except Exception as e:
            cleanup_result['errors'].append(f"扫描日志目录时出错: {str(e)}")
            
        return cleanup_result

    def cleanup(self):
        """
        手动清理资源的公共方法
        """
        try:
            self.logger.info("手动清理LogHelper资源...")
            self._cleanup_on_exit()
        except Exception as e:
            print(f"手动清理失败: {e}")


# 全局日志实例（单例模式）
try:
    log_handler = LogHelper(log_level=logging.INFO)
    logger = log_handler.get_logger()
except Exception as e:
    # 降级处理：如果LogHelper初始化失败，使用基本的logging配置
    print(f"LogHelper初始化失败，使用降级日志配置: {e}")
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s|%(levelname)s|%(process)d|%(thread)d|%(funcName)s|%(filename)s:%(lineno)d|%(message)s'
    )
    logger = logging.getLogger('threshold_system_fallback')
    log_handler = None


def get_logger(name: Optional[str] = None) -> logging.Logger:
    """
    获取logger实例的便捷函数
    
    Args:
        name: logger名称，如果为None则返回全局logger
        
    Returns:
        logging.Logger: logger实例
    """
    if name is None:
        return logger
    else:
        # 为特定模块创建子logger
        child_logger = logger.getChild(name)
        return child_logger


# 使用示例和测试
if __name__ == "__main__":
    print("=== LogHelper测试 ===")
    
    # 测试基本日志输出
    logger.debug("DEBUG信息 - 默认级别下不可见")
    logger.info("INFO信息 - 文件和控制台均可见")
    logger.warning("WARNING信息 - 文件和控制台均可见")
    logger.error("ERROR信息 - 文件和控制台均可见")
    
    # 测试动态调整日志级别（如果log_handler可用）
    if log_handler is not None:
        print("\n=== 调整为DEBUG级别 ===")
        log_handler.setDebugLevel()
        logger.debug("DEBUG信息 - 调整级别后可见")
        logger.info("INFO信息 - 持续可见")
        
        # 显示日志统计信息
        print("\n=== 日志统计信息 ===")
        stats = log_handler.get_log_stats()
        for key, value in stats.items():
            print(f"{key}: {value}")
            
        # 测试强制清理功能
        print("\n=== 测试强制清理功能 ===")
        cleanup_result = log_handler.force_cleanup_logs()
        print(f"清理结果: {cleanup_result}")
        
        # 测试句柄清理功能
        print("\n=== 测试句柄清理功能 ===")
        print("测试上下文管理器...")
        with LogHelper(log_level=logging.DEBUG, log_dir="test_logs") as test_helper:
            test_logger = test_helper.get_logger()
            test_logger.info("测试上下文管理器中的日志")
            test_helper.add_file_handler("context_test.log")
            test_logger.info("测试额外处理器")
        print("上下文管理器测试完成，资源已自动清理")
        
        # 测试手动清理
        print("\n=== 测试手动清理 ===")
        print("当前处理器数量:", len(log_handler.logger.handlers))
        log_handler.cleanup()
        print("手动清理完成")
        
    else:
        print("\n=== LogHelper不可用，跳过高级功能测试 ===")
    
    # 测试子logger
    print("\n=== 测试子logger ===")
    module_logger = get_logger('test_module')
    module_logger.info("来自test_module的信息")
    
    print(f"\n测试完成，请检查logs/{datetime.datetime.now().strftime('%Y%m%d')}/目录下的日志文件")
